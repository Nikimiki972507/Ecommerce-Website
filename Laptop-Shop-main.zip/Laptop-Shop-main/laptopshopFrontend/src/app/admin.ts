export class Admin {
    email!:String;
    keyword!:String;
    password!:String;
}
    
